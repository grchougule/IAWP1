<?php
    session_start();
    include_once 'dbh.inc.php';

    if(isset($_POST['submit']))
    {
        $author=$_SESSION['user_first'];
        $title=$_POST['title'];
        $blog=$_POST['blog'];

        $sql="insert into blogger(author,title,blog) values('".$author."','".$title."','".$blog."');";
        mysqli_query($con,$sql);
        header("location:../homepage.php?msg=success");
    }



?>