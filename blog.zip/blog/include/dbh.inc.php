<?php

    $dbServername="localhost";
    $dbUsername="root";
    $dbpassword="";
    $dbdatabase="blogsystem";

    $con=mysqli_connect($dbServername,$dbUsername,$dbpassword,$dbdatabase);

?>