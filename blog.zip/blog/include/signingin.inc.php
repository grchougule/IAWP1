<?php

    session_start();

    include_once 'dbh.inc.php';

    if(isset($_POST['submit']))
    {
        $user_first=$_POST['firstname'];
        $user_last=$_POST['lastname'];
        $user_email=$_POST['email'];
        $user_uid=$_POST['username'];
        $user_pwd=$_POST['password'];
        //$user_pwd=mysqli_real_escape_string($_POST['password']);

        $_SESSION['user_first']=$user_first;


        $sql="select * from users where user_uid='$user_uid';";
        $result=mysqli_query($con,$sql);
        $resultcheck=mysqli_num_rows($result);

        if($resultcheck>0)
        {
            echo "username already taken";
            header("location:../signup.php?msg=username already exists");
        }
        else
        {
            //$hashedpwd=password_hash($user_pwd,PASSWORD_DEFAULT);
            $sql="insert into users(user_first,user_last,user_email,user_uid,user_pwd) values('".$user_first."','".$user_last."','".$user_email."','".$user_uid."','".$user_pwd."');";
            mysqli_query($con,$sql);
            header("location:../homepage.php");
        }
    }
?>