<?php

    session_start();

    include_once 'dbh.inc.php';

    if(isset($_POST['submit']))
    {
        $user_uid=$_POST['username'];
        $user_pwd=$_POST['password'];


        $sql="select * from users where user_uid='$user_uid';";
        $result=mysqli_query($con,$sql);
        $resultcheck=mysqli_num_rows($result);

        if($resultcheck==0)
        {
            header("location:../index.php?msg=username doesnt exists");
        }
        else
        {
            $sql="select * from users where user_uid='$user_uid';";
            $result=mysqli_query($con,$sql);
            $row=mysqli_fetch_assoc($result);
            //$hashedpwdCheck=password_verify($user_pwd,$row['user_pwd']);
            if($row['user_pwd']==$user_pwd)
            {
                header("location:../homepage.php?msg=success");
                $_SESSION['user_first']=$row['user_first'];
            }
            else
            {
                header("location:../index.php?msg=wrong password");
            }
        }

    }

?>