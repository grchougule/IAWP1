<!DOCTYPE html>
<html>
	<head>
		<title>LogIn to our website</title>
	</head>

	<body>
		<h1>Please Log In to our Website</h1>
		<div>
			<form method="POST" action="include/loggingin.inc.php">
				<label for="username">Enter the Username</label><br>
				<input type="text" name="username"><br>
				<label for="password">Enter the Password</label><br>
				<input type="password" name="password"><br>
				<button name="submit">Log-In</button>
			</form>
		</div>
	</body>
</html>