<!DOCTYPE html>
<html>
	<head>
		<title>My website</title>
	</head>

	<body>
		<h1>WELCOME</h1>
		<div>
			<form method="POST" action="login.php">
				<button name="login" >LOGIN</button>
			</form>
			<form method="POST" action="signin.php">
				<button name="signin" >SIGNUP</button>
			</form>
		</div>
	</body>
</html>