<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<title>My website</title>
	</head>

	<body>
		<!-- <h1>WELCOME</h1>
		<?php
		echo $_SESSION['firstname']."<br>".$_SESSION['lastname'];
		?> -->

		<form action="include/blogging.inc.php" method="POST">
			<textarea rows="20" cols="50" name="blog"></textarea><br>
			<button name="submit">Submit</button>
		</form>

	</body>
</html>
