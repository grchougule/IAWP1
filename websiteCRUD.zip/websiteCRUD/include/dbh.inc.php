<?php

	$dbServername="localhost";
	$dbUsername="root";
	$dbPassword="";
	$dbName="loginsystem";

	$con=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

?>