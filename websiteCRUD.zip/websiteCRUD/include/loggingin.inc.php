<?php
	session_start();
	include_once 'dbh.inc.php';



	if (isset($_POST['submit'])) {
		# code...
		$uname=$_POST['username'];
		$pwd=$_POST['password'];

		//for session variables
		$sql="select user_first,user_last from users where user_pwd='$pwd' and user_uid='$uname';";
		$results=mysqli_query($con,$sql);
		$resultcheck=mysqli_num_rows($results);
		if($resultcheck>0)
		{
			while($row=mysqli_fetch_assoc($results)){
			$_SESSION['firstname']=$row['user_first'];
			$_SESSION['lastname']=$row['user_last'];
			}	
		}
	

		$sql="select * from users;";
		$results=mysqli_query($con,$sql);
		$resultcheck=mysqli_num_rows($results);

		if ($resultcheck<1) {
			# code...
			echo "username Doesnt Exist";
		}
		else {
			# code...
			$sql="select * from users where user_pwd='$pwd';";
			$results=mysqli_query($con,$sql);
			$resultcheck=mysqli_num_rows($results);
			if ($resultcheck<1) {
				# code...
				echo "wrong password";
			}
			else{
				header("location: ../homepage.php?signup=success");
			}

			
		}

	}

?>