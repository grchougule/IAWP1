<?php
	session_start();
	include_once 'dbh.inc.php';


	

	$firstName=$_POST['user_first'];
	$lastName=$_POST['user_last'];
	$email=$_POST['user_email'];
	$uname=$_POST['username'];
	$pwd=$_POST['password'];

	$_SESSION['firstname']=$firstName;
	$_SESSION['lastname']=$lastName;



	$sql="select * from users where user_uid='$uname';";
	$result=mysqli_query($con,$sql);
	$resultCheck=mysqli_num_rows($result);

	if ($resultCheck>0) {
		# code...
		header("location:../signin.php");
	}

	else
	{
		header("location:../homepage.php");
	}

?>