<?php 

session_start();

include_once 'dbh.inc.php';

	if(isset($_POST['submit'])) {
		$sql="insert into blog(user_first,user_last,blog) values('".$_SESSION['firstname']."','".$_SESSION['lastname']."','".$_POST['blog']."');";
		mysqli_query($con,$sql);

		header("location:../homepage.php?success=success");

		
	}

?>