<!DOCTYPE html>
<html>
	<head>
		<title>SIGNIN to our website</title>
	</head>

	<body>
		<h1>Please SIGN In to our Website</h1>
		<div>
			<form method="POST" action="include/signingin.inc.php">
				<label for="user_first">Enter the First Name</label><br>
				<input type="text" name="user_first"><br>
				<label for="user_last">Enter the Last Name</label><br>
				<input type="text" name="user_last"><br>
				<label for="user_email">Enter the E-mail</label><br>
				<input type="email" name="user_email"><br>
				<label for="username">Enter the Username</label><br>
				<input type="text" name="username"><br>
				<label for="password">Enter the Password</label><br>
				<input type="password" name="password"><br>
				<button name="submit">Log-In</button>
			</form>
		</div>
		
	</body>
</html>